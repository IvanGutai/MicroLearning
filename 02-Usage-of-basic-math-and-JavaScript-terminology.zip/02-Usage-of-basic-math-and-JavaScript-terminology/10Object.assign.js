let object1 = {
    a: 1,
    b: 2,
    c: 3
};

console.log(object1.a, object1.b, object1.c, object1.d);
  // expected output:  1 2 3 undefined

// C !
const object2 = Object.assign({ c: 4, d: 5 }, object1);

console.log(object2.a, object2.b, object2.c, object2.d);
  // expected output:  1 2 3 5