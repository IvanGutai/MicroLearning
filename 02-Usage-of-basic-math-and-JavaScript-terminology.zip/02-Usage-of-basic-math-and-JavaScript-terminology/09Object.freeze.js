//'use strict'
const object1 = {
    property: 10
};
object1.property = 50;

const object2 = {
    property: 20
};
Object.freeze(object2);

// Throws an error in strict mode
object2.property = 60;

console.log("O1 " + object1.property);
console.log("O2 " + object2.property);


const object3 = object1;
object3.property = 40;

console.log("O1 " + object1.property);
console.log("O2 " + object2.property);
console.log("O3 " + object3.property);