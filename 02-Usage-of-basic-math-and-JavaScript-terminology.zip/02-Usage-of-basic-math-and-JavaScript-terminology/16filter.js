//ES5
var words = ['spray', 'limit', 'elite', 'exuberant', 'enthusiasm', 'present'];

var result = words.filter(function (word) {
  return word.length > 6;
});

console.log(result);
// expected output: Array ["exuberant", "enthusiasm", "present"]

//ES6
/*
var words = ['spray', 'limit', 'elite', 'exuberant', 'enthusiasm', 'present'];

const result = words.filter(word => word.length > 6);

console.log(result);
*/
// expected output: Array ["exuberant", "enthusiasm", "present"]