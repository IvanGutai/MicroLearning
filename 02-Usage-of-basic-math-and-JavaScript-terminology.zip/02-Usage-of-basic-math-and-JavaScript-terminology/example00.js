/*  -------------------------------------------------------------------------
                                    STATEMENTS
    ------------------------------------------------------------------------- */
console.log('- If statement -');

var isDeveloper = true;     //var isDeveloper = 'jeste';
if (isDeveloper) {          //if (isDeveloper === 'jeste') {
    console.log('He/she <3 to code!');
} else {
    console.log('He/she doesn\'t undestand IT people.');
}
console.log('-------');


console.log('- Switch statement -');

var profession = prompt('What is your profession?');
console.log('Response from switch:');

switch(profession){
    case 'engineer':
        console.log('You are contributing to the society.');
        break;
    case 'developer':
        console.log('You have a ton of $$$.');
        break;
    default:
        console.log('Everybody does what makes him/her happy.');

}

console.log('----------------------------------------------------');

/*  -------------------------------------------------------------------------
                                    FUNCTIONS
    ------------------------------------------------------------------------- */
console.log('- Function -');
var square = function(number){
    return number*number;
}
var x = square(4);
console.log("Square function result : " +  x);
var years = new Array(2011, 2013, 2015, 2017);
console.log('Initial array values: ' + years);
var strongest = years[2];
console.log(strongest);
console.log(years.indexOf(2015));
years.push(2019);
console.log('Array values after push(): ' + years);
years.unshift(2009);
console.log('Array values after unshift(): ' + years);
years.pop();
console.log('Array values after pop(): ' + years);
years.shift();
console.log('Array values after shift(): ' + years);
console.log('----------------------------------------------------');

/*  -------------------------------------------------------------------------
                                    OBJECTS
    ------------------------------------------------------------------------- */
var ivan = {
    name: 'Ivan',
    lastName: 'Gutai',
    academicDegree: 'MScEE',
    yearOfBirth: 1986,
    yearOfFirstEmployment: 2011,
    job: 'Expert Associate - Laboratory specialist',
    yearsInPrivateSector: 6,
    yearsInPublicSector: 1
};

console.log(ivan);
console.log(ivan.name);
console.log(ivan['lastName']);



/*  -------------------------------------------------------------------------
                                    LOOPS
    ------------------------------------------------------------------------- */
console.log('- Array of letters-');
var letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
console.log(letters);
console.log('-------');

/*  for(initializer; exit condition; final expression) */
console.log('- For loop -');
var result = '';
for (var i = 0; i < letters.length; i++) {
    result += letters[i] + ' ';
}
console.log(result);
console.log('-------');


console.log('- For loop backwards -');
var result = '';
for (var i = letters.length - 1; i >= 0; i--) {
    result += letters[i] + ' ';
}
console.log(result);
console.log('-------');

console.log('- For loop, what is break, what is continue? -');
var result = '';
for (var i = 0; i < letters.length; i++) {
    if( letters[i] === 'D')
    {
        continue;
    }
    else if (letters[i] === 'H')
    {
        break;
    }
    result += letters[i] + ' ';
}
    console.log(result);
    console.log('-------');

/*  -------------------------------------------------------------------------
                                    LOOPS (continued)
    ------------------------------------------------------------------------- */
console.log('- do while');
var result = '';
var i = 0;
do {
   i += 1;
   result += i + ' ';
} while (i < 5);
console.log(result);
console.log('-------');

console.log('- do while, wrong condition');
var result = '';
var i = 0;
do {
   i += 1;
   result += i + ' ';
} while (i > 5);
console.log(result);
console.log('-------');

console.log('- while');
var result = '';
var i = 0;
while (i < 5){
   i += 1;
   result += i + ' ';
}
console.log(result);
console.log('-------');

console.log('- while, wrong condition');
var result = '';
var i = 0;
while (i > 5){
   i += 1;
   result += i + ' ';
}
console.log(result);
console.log('----------------------------------------------------');

/*  -------------------------------------------------------------------------
                                    SCOPES
    ------------------------------------------------------------------------- */

var a = 'A';
var d;

console.log(a);
first();

function first() {
    var b = 'B';
    console.log(a + b);
    second();
    
    function second() {
        var c = 'C';
        console.log(a + b + c + ' ' + d);
        d = 'D';
        third();
    return c, d;
    }
}

function third() {
    var e = 'E';
    console.log(a + d + e);
}

// example.js:193 Uncaught ReferenceError: c is not defined at example.js:193
//console.log(c); 
console.log(d);


/*  -------------------------------------------------------------------------
                                    THIS keyword
    ------------------------------------------------------------------------- */
console.log(this);
var ivan = {
    name: 'Ivan',
    lastName: 'Gutai',
    yearOfBirth: 1986,
    calculateAge: function() {
        console.log(this);
        
        function innerFunction() {
            console.log(this);
        }
        innerFunction();
    }
};

ivan.calculateAge();
