/*  -------------------------------------------------------------------------
                                    Events
    ------------------------------------------------------------------------- */

// Random grade generator on example with event listener

var min = 6;
var max = 10;

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

var items = document.getElementsByClassName("grade");

document.getElementById("generateGrades").addEventListener("click", function () {

    for (i = 0; i < items.length; i++) {
        var randomInt = getRandomInt(min, max);
        document.getElementById(items[i].id).innerText = randomInt;
        console.log('Row:' + i + ', value: ' + randomInt);

    }
    console.log('----------');

});

