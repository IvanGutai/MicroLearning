function Product(name, price) {
    this.name = name;
    this.price = price;
}

function Food(name, price) {
    Product.call(this, name, price);
    this.category = 'food';
}
console.log(typeof(Food));

var x = new Food('cheese', 5);
console.log("Name: " + x.name + ", Price: " + x.price + ", Category: " + x.category);