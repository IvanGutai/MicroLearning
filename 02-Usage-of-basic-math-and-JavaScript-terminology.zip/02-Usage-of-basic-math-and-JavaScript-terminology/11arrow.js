var materials = [
    'Hydrogen',
    'Helium',
    'Lithium',
    'Beryllium'
];

//ES5
console.log(materials.map(function (x) { return x.length }));

//ES6
console.log(materials.map(material => material.length));
  // expected output: Array [8, 6, 7, 9]