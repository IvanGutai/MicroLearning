/*  -------------------------------------------------------------------------
                                    Inferitance and the Prototype Chain
    ------------------------------------------------------------------------- */

/*
var ivan = {
    name: 'Ivan',
    lastName: 'Gutai',
    academicDegree: 'MScEE',
    yearOfBirth: 1986
};
*/

var Person = function(name, lastName, academicDegree, yearOfBirth, yearOfFirstEmployment) {
    this.name = name;
    this.lastName = lastName;
    this.academicDegree = academicDegree;
    this.yearOfBirth = yearOfBirth;
    this.yearOfFirstEmployment = yearOfFirstEmployment;
}

Person.prototype.calculateProfessionalCareerStart = function() {
        return this.yearOfFirstEmployment - this.yearOfBirth;
    };

var ivan = new Person('Ivan', 'Gutai', 'MScEE', 1986, 2011);
var student1 = new Person('Developer', '1', 'one step away from MScEE', 1996, 2019);

console.log(ivan);
console.log(ivan.name + ' started professional career with ' + ivan.calculateProfessionalCareerStart() +'.');

console.log(student1);
console.log(student1.name + ' started professional career with ' + student1.calculateProfessionalCareerStart() +'.');

var personProto = {
    calculateProfessionalCareerStart: function() {
        console.log(this.yearOfFirstEmployment - this.yearOfBirth);
        return this.yearOfFirstEmployment - this.yearOfBirth;
    }
}
var student2 = Object.create(personProto,
{
    name: { value: "Administrator"},
    lastName: { value: "1"},
    academicDegree: { value: "one step away from MScEE"},
    yearOfBirth: { value: 1996},
    yearOfFirstEmployment: { value: 2019},
}
);
console.log(student2);
student2.calculateProfessionalCareerStart();

// Primitives
var a = 10;
var b = a;  // value type
a = 46;
console.log(a);
console.log(b);

// Objects
var object1 = {
    name: 'Ivan',
    age: 32
};
var object2 = object1;  // reference type

object1.age = 33;
console.log(object1.age);
console.log(object2.age);

// Passing functions as arguments
var years = [1986, 1992, 1998, 2004, 2010];

// Function1 is an example of callback function
function calculateArray(array1, function1) {
    var resultingArray = [];
    for (var i = 0; i < array1.length; i++)
    {
        resultingArray.push(function1(array1[i]));
    }
    return resultingArray;
}

var year = new Date().getFullYear();
console.log(year);

function calculateAge(element){
    return year - element;
}

function checkIfIsAdult(element){
    return element >= 18;
}

function calculateMaximumHeartRates(element){
    return 220 - element;
}
var ages = calculateArray(years, calculateAge);
console.log(ages);

var adult = calculateArray(ages, checkIfIsAdult);
console.log(adult);

var maximumHeartRates = calculateArray(ages, calculateMaximumHeartRates);
console.log(maximumHeartRates);

//IIFE
(function() {
    var randomNumber = Math.round(Math.random()*10);
    console.log(randomNumber);
    console.log(randomNumber >= 5);
})();