var input = [1,2,3,10];

function copyArrayAndManipulate(array, instructions) {
    var output = [];
    for (var i = 0; i < array.length; i++) {
        output.push(instructions(array[i]));
        console.log(output);
    }
    return output;
}

function multiplyBy2(input) {
    console.log(input * 2 + "                        multiplyBy2");
    return input * 2;
}

function divideBy2(input) {
    console.log(input / 2 + "                        divideBy2");
    return input / 2;
}

var multiplicationResult = copyArrayAndManipulate(input, multiplyBy2);
var divisionResult = copyArrayAndManipulate(input, divideBy2);

console.log("**************************************");
console.log("Multiplication results: " + multiplicationResult);
console.log("Division results: " + divisionResult);