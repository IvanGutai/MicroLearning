function createFunction(array) {
    let i = 0
    function inner() {
        const element = array[i];
        i++;
        return element;
    }
    console.log(inner);
    return inner
}

const returnNextElement = createFunction([4, 5, 6]);
console.log("Next " + returnNextElement);

const element1 = returnNextElement();
console.log("E1 " + element1);
const element2 = returnNextElement();
console.log("E2 " + element2);
const element3 = returnNextElement();
console.log("E3 " + element3);
const element4 = returnNextElement();
console.log("E4 " + element4);