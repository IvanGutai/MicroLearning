class Car {
    constructor() {
        this._currentSpeed = 0;
        this.speedObservers = [];
    }

    subscribeSpeedObserver(observer) {
        if (observer.notify) {
            this.speedObservers.push(observer);
        }
        else {
            throw new Error("Invalid observer. Notify implementation missing.");
        }
    }

    unsubscribeSpeedObserver(observer) {
        let index = this.speedObservers.indexOf(observer);
        if (index > -1) {
            this.speedObservers.splice(index, 1);
        }
    }

    notifySpeedObservers(newVal, oldVal) {
        for (let observer of this.speedObservers) {
            observer.notify(newVal, oldVal);
        }
    }

    get currentSpeed() {
        return this._currentSpeed;
    }

    set currentSpeed(value) {
        let oldVal = this._currentSpeed;
        this._currentSpeed = value;
        if (this._currentSpeed != oldVal) {
            this.notifySpeedObservers(this._currentSpeed, oldVal);
        }
    }
}

class CurrentSpeedConsoleObserver {
    notify(newVal, oldVal) {
        console.log(`Current speed changed from ${oldVal} to ${newVal}`);
    }
}

class CurrentSpeedDOMObserver {
    constructor(selector) {
        this.textField = document.querySelector(selector);
    }

    notify(newVal, oldVal) {
        this.textField.textContent = newVal;
    }
}

let car = new Car();
let consoleObserver = new CurrentSpeedConsoleObserver();
let domObserver = new CurrentSpeedDOMObserver("#speedometer");
car.subscribeSpeedObserver(consoleObserver);
car.subscribeSpeedObserver(domObserver);

//ES6
let interval = setInterval(() => {
    car.currentSpeed += 10;
}, 1500);

setTimeout(() => {
    //car.unsubscribeSpeedObserver(consoleObserver);
    car.unsubscribeSpeedObserver(domObserver);
}, 3500);

setTimeout(() => {
    clearInterval(interval);
}, 10000);

/* ES5
var interval = setInterval(function () {
    car.currentSpeed += 10;
}, 1500);

setTimeout(function () {
    //car.unsubscribeSpeedObserver(consoleObserver);
    car.unsubscribeSpeedObserver(domObserver);
}, 3500);

setTimeout(function () {
    clearInterval(interval);
}, 10000);
*/