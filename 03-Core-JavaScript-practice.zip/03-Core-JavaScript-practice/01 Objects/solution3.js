// ES5 (5th Edition) 2009

function User(name, age) {
    this.name = name;
    this.age = age;
}

User.prototype.increment = function () {
    this.age++;
};

User.prototype.login = function () {
    console.log("login");
};

var user1 = new User("Dev1", 32);
var user2 = new User("Dev2", 24);

console.log("User1: " + user1.age + " User2: " + user2.age);
user1.increment();
console.log("User1: " + user1.age + " User2: " + user2.age);
user2.increment();
console.log("User1: " + user1.age + " User2: " + user2.age);
console.log(typeof user1);
console.log(typeof User);