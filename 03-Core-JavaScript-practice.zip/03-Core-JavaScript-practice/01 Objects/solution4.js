// ES6 (6th Edition) - ECMAScript 2015

class User {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
    increment() {
        this.age++;
    }
    login() {
        console.log("login");
    }
}
let user1 = new User("Dev1", 32);
let user2 = new User("Dev2", 24);

console.log(`User1: ${user1.age} User2: ${user2.age}`);
user1.increment();
console.log(`User1: ${user1.age} User2: ${user2.age}`);
user2.increment();
console.log(`User1: ${user1.age} User2: ${user2.age}`);
console.log(typeof user1);
console.log(typeof User);