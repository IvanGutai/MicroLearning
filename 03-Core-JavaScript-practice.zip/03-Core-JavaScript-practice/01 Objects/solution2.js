// ES5 (5th Edition) 2009

function userCreator(name, age) {
    var newUser = Object.create(userFunctionStore);
    newUser.name = name;
    newUser.age = age;
    return newUser;
};
var userFunctionStore = {
    increment: function increment() {
        this.age++;
    },
    login: function login() {
        console.log("You're logged in");
    }
};
var user1 = userCreator("Dev1", 32);
var user2 = userCreator("Dev2", 24);

// ES6 (6th Edition) - ECMAScript 2015

/*
function userCreator(name, age) {
    let newUser = Object.create(userFunctionStore);
    newUser.name = name;
    newUser.age = age;
    return newUser;
};
let userFunctionStore = {
    increment: function () { this.age++; },
    login: function () { console.log("You're logged in"); }
};
let user1 = userCreator("Dev1", 32);
let user2 = userCreator("Dev2", 24);
*/

console.log("User1: " + user1.age + " User2: " + user2.age);
user1.increment();
console.log("User1: " + user1.age + " User2: " + user2.age);
user2.increment();
console.log("User1: " + user1.age + " User2: " + user2.age);
console.log(typeof user1);
console.log(typeof userCreator);