// ES5 (5th Edition) 2009

function userCreator(name, age) {
    var newUser = {};
    newUser.name = name;
    newUser.age = age;
    newUser.increment = function () {
        newUser.age++;
    };
    return newUser;
};

var user1 = userCreator("Dev1", 32);
var user2 = userCreator("Dev2", 24);

console.log("User1: " + user1.age + " User2: " + user2.age);
user1.increment();
console.log("User1: " + user1.age + " User2: " + user2.age);
user2.increment();
console.log("User1: " + user1.age + " User2: " + user2.age);
console.log(typeof user1);
console.log(typeof userCreator);