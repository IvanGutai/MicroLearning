function* createFlow() {
    const num = 10
    const newNum = yield num
    yield 5 + newNum
    yield 6
}
const returnNextElement = createFlow()
const element1 = returnNextElement.next() // 10
console.log(element1)
const element2 = returnNextElement.next(4) // 9
console.log(element2)
const element3 = returnNextElement.next() // 6
console.log(element3)