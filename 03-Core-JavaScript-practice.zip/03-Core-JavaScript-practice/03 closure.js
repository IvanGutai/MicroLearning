function outer() {
    let counter = 10;
    function incrementCounter() {
        counter++;
        console.log(counter);
    }
    return incrementCounter;
}
let myNewFunction = outer(); // myNewFunction = incrementCounter

myNewFunction();
myNewFunction();