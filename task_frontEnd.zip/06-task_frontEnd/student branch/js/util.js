var myChart;
var a, b = [];
var pressureData, rainfallData = [];

var reducer = function (accumulator, currentValue) {
    return accumulator + currentValue
}

//******************************* HELPER FUNCTIONS *******************************
function countProperties(inData) {
    return Object.keys(inData).length;
}

function Object_values(obj) {
    var vals = [];
    for (var prop in obj) {
        vals.push(obj[prop]);
    }
    return vals
}

// Extra work - Only for refactoring 
// function MesurementUnit(keys, values) {
//     var newUnit = {};
//     this.keys = keys;
//     this.values = values;
//     return newUnit
// }

//******************************* HTTP CLIENT *******************************
class HttpClient {
    get(url) {
        return fetch(url).then(response => response.json());
    }
}

//******************************* Weather Service *******************************
class WeatherService {
    //<- 
    constructor(pressure, rainfall) {
        this.pressure = pressure;
        this.rainfall = rainfall;
    }

    configure(config) {
        this.configureHttpClient(config);
        this.configureEndpoints(config);
    }

    configureHttpClient(config) {
        if (!config.httpClient) {
            throw new Error("HttpClient not configured.")
        }
        this.httpClient = config.httpClient;
    }

    configureEndpoints(config) {
        if (!config.endpoints || !config.endpoints.weatherParameters || !config.endpoints.pressure || !config.endpoints.rainfall) {
            throw new Error("Endpoints poorly configured.")
        }
        this.weatherParametersEndpoints = config.endpoints.weatherParameters;
        //<- 
        this.pressureEndpoints = config.endpoints.pressure;
        this.rainfallEndpoints = config.endpoints.rainfall;
    }

    getWeatherParameters() {
        this.weatherParameters = this.httpClient.get(this.weatherParametersEndpoints)
        return this.weatherParameters;
    }

    getPressure() {
        weatherService.pressure = this.httpClient.get(this.pressureEndpoints)
        return weatherService.pressure;
    }

    getRainfall() {
        weatherService.rainfall = this.httpClient.get(this.rainfallEndpoints)
        return weatherService.rainfall;
    }
    //<- 

}

class WeatherServiceFactory {
    prepareInstance() {
        let config = {
            httpClient: new HttpClient(),
            endpoints: {
                //<- 
                weatherParameters: "./unsortedData/extractedData.json",
                pressure: "./unsortedData/extractedData_Pressure.json",
                rainfall: "./unsortedData/extractedData_Rainfall.json"
            }
        }
        this.weatherService = new WeatherService();
        this.weatherService.configure(config);
    }

    getInstance() {
        if (!this.weatherService) {
            this.prepareInstance();
            console.log("** This is new instance. **")
        }
        else {
            console.log("** Using existing instance... **")
        }
        return this.weatherService;
    }
}

let weatherServiceFactory = new WeatherServiceFactory();
let weatherService = weatherServiceFactory.getInstance();

weatherService.getWeatherParameters().then(weatherParameters => console.log("weatherParameters: ", weatherParameters[0]));

//Show all Object in Firefox
//weatherService.getWeatherParameters().then(weatherParameters => console.log("Pressure: ", weatherParameters[0].Pressure.toSource()));
//weatherService.getWeatherParameters().then(weatherParameters => console.log("Rain Fall: ", weatherParameters[0].Rainfall.toSource()));

function tryToExtractSpecificData(chartNumber) {
    return new Promise(
        function (resolve, reject) {
            try {
                switch (chartNumber) {
                    //<- 
                    case 1:
                        resolve(weatherService.getPressure());
                        break;
                    case 2:
                        resolve(weatherService.getRainfall());
                        break;
                    default:
                        console.log('There are only 2 panels.');
                }
            }
            catch {
                var reason = new Error('Problem with getting data.');
                reject(reason); // reject
            }
        }
    );
}

// Extra work - Only for refactoring 
    // function createMyFirstObject(inputData) {
    //     outputData = new MesurementUnit();
    //     outputData.keys = Object.keys(inputData[0]);
    //     outputData.values = Object_values(inputData[0]);

    //     return outputData
    // }

var doStuff = function (chartNumber) {
    tryToExtractSpecificData(chartNumber)
        .then(function (fulfilled) {
            switch (chartNumber) {
                case 1:
                    pressureData = fulfilled;
                    CreateTableFromJSON(chartNumber, fulfilled[0]);
                    chartGenerator(chartNumber, a, b, "line");
                    // Extra work - Only for refactoring 
                        // pressureData = new MesurementUnit();
                        // pressureData.keys = Object.keys(fulfilled[0]);
                        // pressureData.values = Object_values(fulfilled[0]);
                    break;
                case 2:
                    rainfallData = fulfilled;
                    CreateTableFromJSON(chartNumber, fulfilled[0]);
                    chartGenerator(chartNumber, a, b, "line");
                    break;
                //<- 
                default:
                    console.log('There are only 2 panels.');
            }
        })
        .catch(function (error) {
            console.log(error.message);
        });
};

doStuff(1);
doStuff(2);

function CreateTableFromJSON(number, dataSource) {
    var num = "showData" + number;

    a = [];
    b = [];
    var table = document.createElement("table");
    var col = ["Time", "Value"];
    tr = table.insertRow(-1);

    var result = Object.keys(dataSource).map(function (key) {
        return [String(key), dataSource[key]];
        //<- 
    });
    //console.log("Unsorted result: " + result.toSource()); //Show all Object in Firefox

    //<-

    //console.log("Sorted result: " + result.toSource()); //Show all Object in Firefox

    // CREATE DYNAMIC TABLE.
    var table = document.createElement("table");

    // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.
    var tr = table.insertRow(-1);                   // TABLE ROW.

    for (var i = 0; i < col.length; i++) {
        var th = document.createElement("th");      // TABLE HEADER.
        th.innerHTML = col[i];
        tr.appendChild(th);
    }

    // ADD JSON DATA TO THE TABLE AS ROWS.
    for (var i = 0; i < result.length; i++) {

        tr = table.insertRow(-1);

        for (var j = 0; j < col.length; j++) {
            //<-
            var tabCell = tr.insertCell(-1);
            if (j === 0) {
                //<- 
                tabCell.innerHTML = result[i][0];
                a.push(result[i][0]);
            }
            if (j === 1) {
                tabCell.innerHTML = result[i][1];
                b.push(result[i][1]);
            }
        }
    }

    // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
    var divContainer = document.getElementById(num);
    divContainer.innerHTML = "";
    divContainer.appendChild(table);
    return a, b;
}

function chartGenerator(number, X, Y, chartType) {
    myChart = "myChart" + number;
    myLabel = "Sensor " + number;

    ctx = document.getElementById(myChart);
    function calculateAverage(Y) {
        avgPlus = [];
        var result = 0;

        function countProperties(Y) {
            return Object.keys(Y).length;
        }

        tempo = countProperties(Y);

        for (var i = 0; i < tempo; i++) {
            b = Object_values(Y)[i];
            avgPlus.push(b);
        }

        var values = avgPlus;
        if (avgPlus != null) {
            result = ((values.reduce(reducer)) / tempo).toFixed(2);
            avg1 = result;
        }

        return result
    }

    function CalculateMinValue(dataObject) {
        //<-
    }

    function CalculateMaxValue(dataObject) {
        //<-
    }

    var yAverage = calculateAverage(Y);
    //<-


    function createArrayOfSameNumbers(input) {
        var result = [];
        var tempo = countProperties(Y)
        for (var i = 0; i < tempo; i++) {
            result.push(input);
        }
        return result
    }

    var Yaverage = createArrayOfSameNumbers(yAverage);
    //<-

    var chart = new Chart(ctx, {
        type: chartType,
        options: {
            events: ['click'],
            responsive: true
        },
        data: {
            labels: X,
            datasets: [
                {
                    data: Y,
                    label: myLabel,
                    borderColor: "#FFFE2A",
                    fill: false
                }
            ]
        },
    });
    chart.update();
}

/* HELPER //<- 
            1
            nesto.sort(function (prviDatum, drugiDatum) {
                 return new Date(prviDatum[0]) - new Date(drugiDatum[0])
             });

            2
            var options = { year: '2-digit', month: '2-digit', day: '2-digit', hour: 'numeric', minute: '2-digit' }; // second: '2-digit', timeZoneName:'short' 

            var localizedDateAndTime = (new Date(rezultat[i][0])).toLocaleDateString('SR', options);
            celijaUTabeli.innerHTML = localizedDateAndTime;
            niz.push(localizedDateAndTime);

            3

            var minValue;
            var nizPodataka = new Array;
            for (var o in ObjekatSaPodacima) {
                nizPodataka.push(ObjekatSaPodacima[o]);
            }
            minValue = Math.min(...nizPodataka);
            return minValue

            4
            String(indeks.replace(": ", ":").replace(": ", ":")), izvorPodataka[indeks];

            5
            var yMin = CalculateMinValue(Y);
            var yMax = CalculateMaxValue(Y);

            6
                {
                    data: Yaverage,
                    label: "Average (" + yAverage + ") ",
                    borderColor: "#FFFFFF",
                    fill: false
                },
                {
                    data: Ymin,
                    label: "Minimum (" + yMin + ") ",
                    borderColor: "#FFE7D3",
                    fill: false
                },
                {
                    data: Ymax,
                    label: "Maximum (" + yMax + ") ",
                    borderColor: "#FFBE86",
                    fill: false
                }



                7
                var Ymin = createArrayOfSameNumbers(yMin);
                var Ymax = createArrayOfSameNumbers(yMax);

*/

document.addEventListener('DOMContentLoaded', function (event) {
    // array with texts to type in typewriter
    var dataText = ["Zahtevi: Potrebno je na jednoj stranici prikazati rezultate merenja sa tri različita senzora. Fajl sa svim rezultatima je 'extractedData.json', a sadrži sledeće parametre: 'Humidity, Rainfall, WindGust, Temperature, Pressure, WindSpeed i WindDirection.'. Obavezno je prikazati rezultate za WindGust i još sa dva senzora po vašem izboru (preporučeno je da se dogovorite međusobno ko šta radi, da ne bi bilo ponavljanja). Rezultate je potrebno prikazati u TABELI i na GRAFIKU. Tabela treba da sadrži dve kolone, TIME i VALUE, a rezultati da budu prikazani u formatu, npr. '16.10.18. 11:40' i '960.40', respektivno. Prikazuju se svi rezultati, bez ikakvog filtriranja. Grafik treba da sadrži sve podatke, sortirane po vremenu. Opciono je da se prikažu minimalna, maksimalna ili srednja vrednost, na istom grafiku. Grafik treba da ima mogućnosti isključivanja prikaza seta parametara i automatsko prilagođavanje skale (chart.js). Kao rezultat treba da dobijete tri bloka koja u sebi sadrže i grafik i tabelu.  Prilagoditi dizajn svih blokova, da budu u skladu sa prvim blokom. Izbor boja treba da se razlikuje od ovog primera i potrebno je da bude čitko. Na rezolucijama do 1152px je potrebno prikazivati jedan blok ispod drugog, dok je na većim rezolucijama potrebno prikazivati dva bloka, jedan pored drugog. HTML treba da bude personalizovan i da sadrži vaša imena (polje 'author') i vaše brojeve indeksa (polje 'keywords') . JavaScript fajl treba da sadrži isključivo kod koji je potreban za prikaz podataka koje ste odabrali, a nazivi promenljivih treba da budu smisleni. Zbog učitavanja fajlova sa lokalne mašine koristiti za razvoj Brackets sa opcijom 'Live preview' ili neki drugi editor, uz Mozilla Firefox. Za sva dodatna pitanja gutai@uns.ac.rs "];

    // type one text in the typwriter
    // keeps calling itself until the text is finished
    function typeWriter(text, i, fnCallback) {
        // chekc if text isn't finished yet
        if (i < (text.length)) {
            // add next character to h1
            document.querySelector("h1").innerHTML = text.substring(0, i + 1) + '<span aria-hidden="true"></span>';

            // wait for a while and call this function again for next character
            setTimeout(function () {
                typeWriter(text, i + 1, fnCallback)
            }, 100);
        }
        // text finished, call callback if there is a callback function
        else if (typeof fnCallback == 'function') {
            // call callback after timeout
            setTimeout(fnCallback, 700);
        }
    }
    // start a typewriter animation for a text in the dataText array
    function StartTextAnimation(i) {
        if (typeof dataText[i] == 'undefined') {
            setTimeout(function () {
                StartTextAnimation(0);
            }, 20000);
        }
        // check if dataText[i] exists
        if (i < dataText[i].length) {
            // text exists! start typewriter animation
            typeWriter(dataText[i], 0, function () {
                // after callback (and whole text has been animated), start next text
                //StartTextAnimation(i + 1);
            });
        }
    }
    // start the text animation
    StartTextAnimation(0);
});